var data = {
   books: [
      {
         image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
         name: "滴泪痣"
      },
      {
         image: "http://img3m9.ddimg.cn/77/23/25295369-1_l_9.jpg",
         name: "云边有个小卖部"
      }, {
         image: "http://img3m5.ddimg.cn/76/1/25574845-1_l_5.jpg",
         name: "冷场"
      }, {
         image: "http://img3m0.ddimg.cn/7/27/25137790-1_l_2.jpg",
         name: "活着（2017年新版）"
      }, {
         image: "http://img3m8.ddimg.cn/49/33/25478788-1_l_2.jpg",
         name: "祖与占：夏日之恋"
      }, {
         image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
         name: "滴泪痣"
      }, {
         image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
         name: "滴泪痣"
      }, {
         image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
         name: "滴泪痣"
      }, 
      {
         image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
         name: "滴泪痣"
     }, {
       image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
       name: "滴泪痣"
     },
     {
       image: "http://img3m9.ddimg.cn/77/23/25295369-1_l_9.jpg",
       name: "云边有个小卖部"
     }, {
       image: "http://img3m5.ddimg.cn/76/1/25574845-1_l_5.jpg",
       name: "冷场"
     }, {
       image: "http://img3m0.ddimg.cn/7/27/25137790-1_l_2.jpg",
       name: "活着（2017年新版）"
     }, {
       image: "http://img3m8.ddimg.cn/49/33/25478788-1_l_2.jpg",
       name: "祖与占：夏日之恋"
     }, {
       image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
       name: "滴泪痣"
     }, {
       image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
       name: "滴泪痣"
     }, {
       image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
       name: "滴泪痣"
     },
     {
       image: "http://img3m4.ddimg.cn/44/3/25185644-1_l_1.jpg",
       name: "滴泪痣"
     }
   ]
}
module.exports = {
   bookdata: data
}



